detectron2.config package
=========================

.. automodule:: detectron2.config
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:


Config References
-----------------

.. literalinclude:: ../../detectron2/config/defaults.py
  :language: python
  :linenos:
  :lines: 4-
