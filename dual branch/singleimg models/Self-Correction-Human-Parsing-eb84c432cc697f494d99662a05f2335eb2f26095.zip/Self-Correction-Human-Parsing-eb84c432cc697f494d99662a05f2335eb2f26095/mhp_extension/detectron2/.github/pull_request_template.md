Thanks for your contribution!

If you're sending a large PR (e.g., >50 lines),
please open an issue first about the feature / bug, and indicate how you want to contribute.

Before submitting a PR, please run `dev/linter.sh` to lint the code.

See https://detectron2.readthedocs.io/notes/contributing.html#pull-requests
about how we handle PRs.
